#! /bin/sh
rm $2
