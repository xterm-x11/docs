/*
 * $XTermId: version.h,v 1.62 2022/01/11 22:58:31 tom Exp $
 *
 * http://invisible-island.net/luit/
 */
#define LUIT_VERSION "2.0-20220111"
