/*
 * $XTermId: version.h,v 1.66 2024/01/02 08:57:20 tom Exp $
 *
 * http://invisible-island.net/luit/
 */
#define LUIT_VERSION "2.0-20240102"
