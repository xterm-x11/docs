/*
 * $XTermId: version.h,v 1.65 2023/02/01 23:19:20 tom Exp $
 *
 * http://invisible-island.net/luit/
 */
#define LUIT_VERSION "2.0-20230201"
