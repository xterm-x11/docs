/* $Id: patchlev.h,v 1.82 2022/08/27 13:32:52 tom Exp $ */
#define RELEASE 2
#define PATCHLEVEL 7
#define PATCH_DATE 20220827
